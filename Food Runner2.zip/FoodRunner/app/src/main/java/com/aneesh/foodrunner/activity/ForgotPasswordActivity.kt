package com.aneesh.foodrunner.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.aneesh.foodrunner.utils.CheckCredentials
import com.aneesh.foodrunner.R

class ForgotPasswordActivity : AppCompatActivity() {

    lateinit var etMobile : EditText
    lateinit var etMail : EditText
    lateinit var btnNEXT : Button
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)

        onBindView()
        btnNEXTListener()

    }

    private fun btnNEXTListener() {
        btnNEXT.setOnClickListener{

            val mobile = etMobile.text.toString()
            val mail = etMail.text.toString()
            val checkCredentials = CheckCredentials(this@ForgotPasswordActivity, mobile, mail, "")

            if(checkCredentials.checkMobile() && checkCredentials.checkEmail()){

                savePreferences()

                val intent = Intent(this@ForgotPasswordActivity, DashboardActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
    }

    private fun savePreferences() {
        sharedPreferences.edit().putBoolean("isLoggedIn", true).apply()
    }

    private fun onBindView() {
        etMobile = findViewById(R.id.etMobile)
        etMail = findViewById(R.id.etMail)
        btnNEXT = findViewById(R.id.btnNEXT)
        sharedPreferences = getSharedPreferences(getString(R.string.shared_preference), Context.MODE_PRIVATE)
    }
}