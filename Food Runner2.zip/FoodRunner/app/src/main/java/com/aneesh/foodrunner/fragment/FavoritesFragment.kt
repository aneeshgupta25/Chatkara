package com.aneesh.foodrunner.fragment

import android.content.Context
import android.os.AsyncTask
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.RelativeLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.aneesh.foodrunner.R
import com.aneesh.foodrunner.adapter.FavouriteRecyclerAdapter
import com.aneesh.foodrunner.database.ResDatabase
import com.aneesh.foodrunner.database.ResEntities

class FavoritesFragment : Fragment() {

    lateinit var recycler : RecyclerView
    lateinit var progressLayout : RelativeLayout
    lateinit var progressBar : ProgressBar
    lateinit var resEntityList : MutableList<ResEntities>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_favouries, container, false)

        progressLayout = view.findViewById(R.id.progressLayout)
        progressBar = view.findViewById(R.id.progressBar)
        recycler = view.findViewById(R.id.recycler)
        progressLayout.visibility = View.VISIBLE
        displayList(view)

        return view
    }

    private fun displayList(view : View) {

        resEntityList = RetrieveFavourites(activity as Context).execute().get()
        if(resEntityList != null && activity != null){

            progressLayout.visibility = View.GONE

            recycler = view.findViewById(R.id.recycler)
            val recyclerAdapter = FavouriteRecyclerAdapter(activity as Context, resEntityList)
            val layoutManager = LinearLayoutManager(activity)
            recycler.adapter = recyclerAdapter
            recycler.layoutManager = layoutManager
        }

    }

    class RetrieveFavourites(val context : Context) : AsyncTask<Void, Void, MutableList<ResEntities>>(){
        override fun doInBackground(vararg params: Void?): MutableList<ResEntities> {
            val db = Room.databaseBuilder(context, ResDatabase::class.java, "res_db").build()
            return db.resDao().getAllRes()
        }

    }
}