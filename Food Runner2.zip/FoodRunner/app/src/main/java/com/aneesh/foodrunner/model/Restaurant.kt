package com.aneesh.foodrunner.model

data class Restaurant (

    var id : String,
    var name : String,
    var rating : String,
    var cost_for_one : String,
    var image : String
        )