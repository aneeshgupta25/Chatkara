package com.aneesh.foodrunner.fragment

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.aneesh.foodrunner.R

class ProfileFragment : Fragment() {

    lateinit var tvName : TextView
    lateinit var tvContact : TextView
    lateinit var tvEmail : TextView
    lateinit var tvDelivery : TextView
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_profile, container, false)

        onBindView(view)
        displayCredentials()

        return view
    }

    private fun displayCredentials() {
        tvName.text = sharedPreferences.getString("profileName", "")
        tvContact.text = sharedPreferences.getString("profileContact", "")
        tvEmail.text = sharedPreferences.getString("profileMail", "")
        tvDelivery.text = sharedPreferences.getString("profileDelivery", "")
    }

    private fun onBindView(view : View) {
        tvName = view.findViewById(R.id.tvName)
        tvContact = view.findViewById(R.id.tvContact)
        tvEmail = view.findViewById(R.id.tvEmail)
        tvDelivery = view.findViewById(R.id.tvDelivery)
        sharedPreferences =
            context?.getSharedPreferences(getString(R.string.shared_preference), Context.MODE_PRIVATE)!!
    }
}