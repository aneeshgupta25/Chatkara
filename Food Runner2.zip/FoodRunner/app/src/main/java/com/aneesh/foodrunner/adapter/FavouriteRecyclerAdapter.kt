package com.aneesh.foodrunner.adapter

import android.app.AlertDialog
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.aneesh.foodrunner.R
import com.aneesh.foodrunner.database.ResEntities
import com.aneesh.foodrunner.fragment.HomeFragment
import com.squareup.picasso.Picasso
import com.aneesh.foodrunner.fragment.FavoritesFragment as FavoritesFragment

class FavouriteRecyclerAdapter(val context : Context, var resEntityList : MutableList<ResEntities>) : RecyclerView.Adapter<FavouriteRecyclerAdapter.FragmentViewHolder>() {

    class FragmentViewHolder(view : View) : RecyclerView.ViewHolder(view){
        val txtName : TextView = view.findViewById(R.id.txtName)
        val txtPrice : TextView = view.findViewById(R.id.txtPrice)
        val txtRating : TextView = view.findViewById(R.id.txtRating)
        val imgRecycler : ImageView = view.findViewById(R.id.imgRecycler)
        val checkBox : CheckBox = view.findViewById(R.id.checkBox)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FragmentViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.restaurant_view, parent, false)
        return FragmentViewHolder(view)
    }

    override fun onBindViewHolder(holder: FragmentViewHolder, position: Int) {
        val resEntity = resEntityList[position]
        Picasso.get().load(resEntity.image_url).error(R.drawable.default_food).into(holder.imgRecycler)
        holder.txtName.text = resEntity.name
        holder.txtPrice.text = resEntity.cost_for_one
        holder.txtRating.text = resEntity.rating
        holder.checkBox.isChecked = true

        Log.d("aneesh", "${position} itemName ${resEntity.name}")

        holder.checkBox.setOnClickListener{
            val dialog = AlertDialog.Builder(context)
            dialog.setTitle("Attention")
            dialog.setMessage("Remove from favourites?")
            dialog.setPositiveButton("Remove"){text, listener ->
                val removeFav = HomeFragment.DBAsyncTask(context, resEntity, 3, null).execute().get()
                if(removeFav){
                    Toast.makeText(context, "Removed from Favourites", Toast.LENGTH_SHORT).show()
                    resEntityList.removeAt(position)
                    notifyItemRemoved(position)
                }
                else{
                    Toast.makeText(context, "Some error occurred", Toast.LENGTH_SHORT).show()
                }
            }
            dialog.setNegativeButton("Cancel"){text, listener ->
                holder.checkBox.isChecked = true
            }
            dialog.create().show()
        }
    }

    override fun getItemCount(): Int {
        return resEntityList.size
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getItemViewType(position: Int): Int {
        return position
    }

}