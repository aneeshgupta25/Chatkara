package com.aneesh.foodrunner

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DescriptionActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)
    }

    override fun onBackPressed() {
        finish()
    }

    override fun onDestroy() {
        android.os.Process.killProcess(android.os.Process.myPid())
        super.onDestroy()
    }
}