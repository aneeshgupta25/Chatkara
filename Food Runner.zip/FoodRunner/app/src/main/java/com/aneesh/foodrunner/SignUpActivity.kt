package com.aneesh.foodrunner

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.widget.Toolbar


class SignUpActivity : AppCompatActivity() {

    //Appcompat.widget.toolbar
    lateinit var toolbar : Toolbar
    lateinit var etName : EditText
    lateinit var etMail : EditText
    lateinit var etMobile : EditText
    lateinit var etDelivery : EditText
    lateinit var etChosePassword : EditText
    lateinit var etConfirmPassword : EditText
    lateinit var btnRegister : Button
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        onBindView()
        setupToolBar()
        btnRegisterlistener()
    }

    private fun btnRegisterlistener() {
        btnRegister.setOnClickListener{
            val name = etName.text.toString()
            val mail = etMail.text.toString()
            val phone = etMobile.text.toString()
            val deliveryAdd = etDelivery.text.toString()
            val chosePassword = etChosePassword.text.toString()
            val confirmPassword = etConfirmPassword.text.toString()
            val sharedPreferences = getSharedPreferences(getString(R.string.shared_preference), Context.MODE_PRIVATE)

            val checkCredentials = CheckCredentials(this@SignUpActivity, phone, mail, chosePassword)

            if(name.isEmpty() || name.length < 3){
                Toast.makeText(this@SignUpActivity, "Invalid Name", Toast.LENGTH_SHORT).show()
            }else if(!checkCredentials.checkEmail()){
                //Handled by the checkCredentials class
            }else if(!checkCredentials.checkMobile()){
                //Handled by the checkCredentials class
            }else if(deliveryAdd.isEmpty()){
                Toast.makeText(this@SignUpActivity, "Invalid Address!", Toast.LENGTH_SHORT).show()
            }else if(!checkCredentials.checkPassword()){
                //Handled by the checkCredentials class
            }else if(chosePassword != confirmPassword){
                Toast.makeText(this@SignUpActivity, "Password doesn't match", Toast.LENGTH_SHORT).show()
            }else{
                sharedPreferences.edit().putBoolean("isLoggedIn", true).apply()
                val intent = Intent(this@SignUpActivity, DescriptionActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
    }

    private fun setupToolBar() {
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Register Yourself"
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    private fun onBindView() {
        toolbar = findViewById(R.id.toolbar)
        etName = findViewById(R.id.etName)
        etMail = findViewById(R.id.etMail)
        etMobile = findViewById(R.id.etMobile)
        etDelivery = findViewById(R.id.etDelivery)
        etChosePassword = findViewById(R.id.etChosePassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        btnRegister = findViewById(R.id.btnRegister)
    }
}