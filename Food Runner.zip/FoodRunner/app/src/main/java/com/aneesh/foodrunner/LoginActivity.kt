package com.aneesh.foodrunner

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity() {

    lateinit var etMobile : EditText
    lateinit var etPassword : EditText
    lateinit var btnLogin : Button
    lateinit var txtForgotPassword : TextView
    lateinit var txtSignUp : TextView
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        onBindView()
        btnLoginListener()
        txtSignUpListener()
        txtForgotPasswordListener()
    }

    private fun txtForgotPasswordListener() {
        txtForgotPassword.setOnClickListener{
            val intent = Intent(this@LoginActivity, ForgotPasswordActivity::class.java)
            startActivity(intent)
        }
    }

    private fun txtSignUpListener() {
        txtSignUp.setOnClickListener{
            val intent = Intent(this@LoginActivity, SignUpActivity::class.java)
            startActivity(intent)
        }
    }

    private fun btnLoginListener() {
        btnLogin.setOnClickListener {
            var mobile = etMobile.text.toString()
            var password = etPassword.text.toString()

            val checkCredentials = CheckCredentials(this@LoginActivity, mobile, "", password)

            if(checkCredentials.checkMobile() && checkCredentials.checkPassword()){
                savePreferences(mobile, password)
                val intent = Intent(this@LoginActivity, DescriptionActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
    }

    private fun savePreferences(mobile: String, password: String) {
        sharedPreferences.edit().putBoolean("isLoggedIn", true).apply()
        sharedPreferences.edit().putString("Mobile", mobile).apply()
        sharedPreferences.edit().putString("PassWord", password).apply()
    }

    private fun onBindView() {
        etMobile = findViewById(R.id.etMobile)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        txtForgotPassword = findViewById(R.id.txtForgotPassword)
        txtSignUp = findViewById(R.id.txtSignUp)
        sharedPreferences = getSharedPreferences(getString(R.string.shared_preference), Context.MODE_PRIVATE)
    }
}